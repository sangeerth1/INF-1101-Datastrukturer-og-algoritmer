#include <stdio.h> 
#include <stdlib.h> 
#include "set.h"
#include "list.h"	


/*
 * The type of sets.
 */

typedef struct set set_t;

struct set {
	list_t *liste;
	cmpfunc_t cmpfunc;
	 
};

/*
 * Creates a new set using the given comparison function
 * to compare elements of the set.
 */
set_t *set_create(cmpfunc_t cmpfunc) {
	set_t * set = malloc (sizeof(set_t)); //vi allokerer en plass i minnet 
	set->liste = list_create(cmpfunc);
	set->cmpfunc = cmpfunc;
	return set; 
}

/*
 * Destroys the given set.  Subsequently accessing the set
 * will lead to undefined behavior.
 */
void set_destroy(set_t *set){
	list_destroy(set->liste);
	free(set); //frigjør et minne 
}

/*
 * Returns the size (cardinality) of the given set.
 */
int set_size(set_t *set){ 

	return list_size(set->liste); 


}

/*
 * Adds the given element to the given set.
 */
void set_add(set_t *set, void *elem) {

	if (!list_contains(set->liste, elem))
	{
		list_addfirst(set->liste, elem);
		list_sort(set->liste); 
	}
		
	
	
}

/*
 * Returns 1 if the given element is contained in
 * the given set, 0 otherwise.
 */
int set_contains(set_t *set, void *elem){
	int resultat;							
	resultat = list_contains(set->liste,elem); 
	return resultat ; 

}
	
/*
 * Returns the union of the two given sets; the returned
 * set contains all elements that are contained in either
 * a or b.
 */
set_t *set_union(set_t *a, set_t *b){
	set_t * c; 
	// Tomt set
	c = set_create(a->cmpfunc); 
	set_iter_t *iter_a = set_createiter(a);
	set_iter_t *iter_b = set_createiter(b);

	void *elem;
	while(set_hasnext(iter_a)) 
	{
		elem = set_next(iter_a);
		// Hvis ja, legg til i C
		/*if(set_contains(b,elem)==1){
			if(set_contains(c, elem) == 0){
			set_add(c,elem); 
			}
		} */
		set_add(c,elem);
	}		


	while(set_hasnext(iter_b)){
	elem = set_next(iter_b);

		set_add(c,elem);
	}	

	// Iterere gjennom A
	// For hvert element, legg til i C 

	// Iterere gjennom B
	// For hvert element, legg til i C

	return c; 
}

/*
 * Returns the intersection of the two given sets; the
 * returned set contains all elements that are contained
 * in both a and b.
 */
set_t *set_intersection(set_t *a, set_t *b){
	set_t * c;  
	int k;
	// Tomt set
	c = set_create(a->cmpfunc); 
	set_iter_t *iter_a = set_createiter(a);

	// Iterere gjennom A
	while(set_hasnext(iter_a))
	{
		void *elem = set_next(iter_a);
		// For hvert element, sjekk om element forekommer i B
		k = list_contains(b->liste, elem); 
		// Hvis nei, bare gå videre til neste element
		if (k == 0) continue; 
		// Hvis ja, legg til i C
		set_add(c, elem);
	}
	// Returner C
	return c;


}

/*
 * Returns the set difference of the two given sets; the
 * returned set contains all elements that are contained
 * in a and not in b.
 */
set_t *set_difference(set_t *a, set_t *b){
	set_t * c; 
	int i ; 
	
	c = set_create(b->cmpfunc); 
	set_iter_t *iter_b, *iter_a;

	iter_a = set_createiter(a);
	iter_b = set_createiter(b); 

	void *temp;

	while (set_hasnext(iter_a) != 0) {
		temp = set_next(iter_a);
		if (set_contains(b, temp) == 0) {
			set_add(c, temp);
		}
	}

	// for(i=0,i< set_size(a),i++){ 

	// 	set_hasnext(iter_a); 

	return c; 
	}


/*
 * Returns a copy of the given set.
 */
set_t *set_copy(set_t *set){
	set_t *c; 

	c = set_create(set->cmpfunc); 
	set_iter_t *iter_set = set_createiter(set); 

	while(set_hasnext(iter_set))
	{
		void *elem = set_next(iter_set);

		set_add(c,elem);
	}

	return c; 


}

/*
 * The type of set iterators.
 */
struct set_iter;
typedef struct set_iter set_iter_t;
struct set_iter { 

	list_iter_t *list_iter; 

};

/*
 * Creates a new set iterator for iterating over the given set.
 */
set_iter_t *set_createiter(set_t *set){
	if (set == NULL) {
		printf("sett er NULL, kan ikke lage iterator!\n");
		return NULL;
	}

     set_iter_t *set_iter;
     set_iter = malloc(sizeof(set_iter_t));
     set_iter->list_iter = list_createiter(set->liste);
     if (set_iter == NULL){
     	printf("out of memory");
     	return 0;
     }
     return set_iter;
}
	

/*
 * Destroys the given set iterator.
 */
void set_destroyiter(set_iter_t *set_iter){
	list_destroyiter(set_iter->list_iter);
	free(set_iter); 
}

/*
 * Returns 0 if the given set iterator has reached the end of the
 * set, or 1 otherwise.
 */
int set_hasnext(set_iter_t *set_iter){  

	if(list_hasnext(set_iter->list_iter) == 0){
		return 0;
	}else{
		return 1;
	}
	
}

/*
 * Returns the next element in the sequence represented by the given
 * set iterator.
 */
void *set_next(set_iter_t *set_iter){ 

	return(list_next(set_iter->list_iter));


}

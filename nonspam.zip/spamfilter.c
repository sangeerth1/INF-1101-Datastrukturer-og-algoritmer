/* Author: Steffen Viken Valvaag <steffenv@cs.uit.no> */
#include "list.h"
#include "set.h"
#include "common.h"
#include <string.h> 
/*
 * Case-insensitive comparison function for strings.
 */
static int compare_words(void *a, void *b)
{
    return strcasecmp(a, b);
}

#define debug printf("%s:%d\n", __FUNCTION__, __LINE__);

/*
 * Returns the set of (unique) words found in the given file.
 */
static set_t *tokenize(char *filename)
{
	set_t *wordset = set_create(compare_words);
	list_t *wordlist = list_create(compare_words);
	list_iter_t *it;
	FILE *f;


	f = fopen(filename, "r");
	if (f == NULL) {
		perror("fopen");
		fatal_error("fopen() failed");
	}

	tokenize_file(f, wordlist);


	it = list_createiter(wordlist);
	while (list_hasnext(it)) {
		set_add(wordset, list_next(it));		
	}
	list_destroyiter(it);
	list_destroy(wordlist);
	return wordset;
}

/*
 * Prints a set of words.
 */
static void printwords(char *prefix, set_t *words)
{
	set_iter_t *it;
	
	it = set_createiter(words);
	printf(prefix);
	while (set_hasnext(it)) {
		printf(" %s", set_next(it));
	}
	printf("\n");
	set_destroyiter(it);
}

/*
 * Main entry point.
 */
int main(int argc, char **argv)
{

	char *spamdir, *nonspamdir, *maildir;
	
	if (argc != 4) {
		fprintf(stderr, "usage: %s <spamdir> <nonspamdir> <maildir>\n",
				argv[0]);
		return 1;
	}
	spamdir = argv[1];
	nonspamdir = argv[2];
	maildir = argv[3];

/*
	set_t *spam_set;
	spam_set = tokenize(spamdir); 
	set_t * nonspam_set;
	nonspam_set = tokenize(nonspamdir); 
	set_t *mail_set; 
	mail_set = tokenize(maildir);
	*/

	list_t *spamfiles = find_files(spamdir);

	char *filename;
	list_iter_t *iter = list_createiter(spamfiles); 

	set_t *intersect = tokenize(list_next(iter));

	while(list_hasnext(iter)) 
	{
		filename = list_next(iter);
		set_t *pointer = tokenize(filename); 
		intersect = set_intersection(intersect, pointer);
		set_destroy(pointer);
    
	}	


     //union for notspam
	list_t *notspam = find_files(nonspamdir); 
	list_iter_t *iter_notspam = list_createiter(notspam);
	set_t *union1 = tokenize(list_next(iter_notspam));



	while(list_hasnext(iter_notspam))
	{
		set_t *pointer = tokenize(list_next(iter_notspam));
		union1 = set_union(union1,pointer); 
		set_destroy(pointer);
	}
	/*
	for(int i = 0;i<list_size(notspam);i++){
		set_t *pointer = tokenize(list_next(iter_notspam));
		union1 = set_union(union1,pointer); 
		set_destroy(pointer);
	}
	*/



	list_t *mailfil = find_files(maildir); 
	list_iter_t *iter_mail = list_createiter(mailfil); 


	 // set for known spammwords
	set_t *difference = set_difference(intersect, union1);

	while(list_hasnext(iter_mail))
	{
		filename = list_next(iter_mail);
		set_t *pointer = tokenize(filename);
		pointer = set_intersection(pointer, difference);

		printf("%s: ", filename);

		if(set_size(pointer) == 0){
			printf("ikke spam\n");
		} 

		else{ printf("spam\n");

		}
		set_destroy(pointer); 
	}
/*
	for(int i = 0; i<list_size(mailfil);i++){
		set_t *pointer = tokenize(list_next(iter_mail));
		pointer = set_intersection(pointer, difference);
		if(set_size(pointer) == 0){
			printf("ikke spam\n");
		} 

		else{ printf("spam\n");

		}
		set_destroy(pointer); 

		

	}
*/		

    return 0;
}
	
		
	